import requests
from django.shortcuts import render, redirect
from django.core.paginator import Paginator
from datetime import datetime

def lista_medicamentos(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}"
    }

    try:
        response = requests.get("http://localhost:3000/api/medicamentos/all", headers=headers)
        if response.status_code == 200:
            medicamentos = response.json()
        else:
            medicamentos = []
    except requests.RequestException:
        medicamentos = []

    return render(request, 'core/medicamentos.html', {'medicamentos': medicamentos})

# vista de login
def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        contraseña = request.POST.get("contraseña")

        try:
            response = requests.post("http://localhost:3000/api/auth/login", json={
                "email": email,
                "contraseña": contraseña
            })

            if response.status_code == 201:
                token = response.json().get("access_token")
                request.session["jwt"] = token
                return redirect("medicamentos")
            else:
                return render(request, "core/login.html", {"error": "Credenciales incorrectas."})
        
        except requests.RequestException:
            return render(request, "core/login.html", {"error": "Error al conectar con la API."})

    return render(request, "core/login.html")

def logout_view(request):
    request.session.flush()
    return redirect("login")


  


# vista de reportes
def report_view(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}"
    }

    try:
        response = requests.get("http://localhost:3000/api/medicamentos/all", headers=headers)
        if response.status_code == 200:
            reports = response.json()
        else:
            reports = []
    except requests.RequestException:
        reports = []

    return render(request, 'core/reports.html', {'reports': reports})



# vista de pedidos
def order_view(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}"
    }

    try:
        response = requests.get("http://localhost:3000/api/medicamentos/all", headers=headers)
        if response.status_code == 200:
            orders = response.json()
        else:
            orders = []
    except requests.RequestException:
        orders = []

    return render(request, 'core/orders.html', {'orders': orders})

# vista de proveedores


# vista de configuracion
def settings_view(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}"
    }

    try:
        response = requests.get("http://localhost:3000/api/medicamentos/all", headers=headers)
        if response.status_code == 200:
            settings = response.json()
        else:
            settings = []
    except requests.RequestException:
        settings = []

    return render(request, 'core/settings.html', {'settings': settings})



def create_medicamento_view(request):
    proveedores = []
    error = None


    try:
        response = requests.get("http://localhost:3000/api/proveedores/all")
        if response.status_code == 200:
            proveedores = response.json()
    except requests.RequestException:
        error = "No se pudieron obtener los proveedores."

    if request.method == "POST":
        nombre = request.POST.get("nombre")
        lote = request.POST.get("lote")
        caducidad = request.POST.get("caducidad")
        stock = request.POST.get("stock")
        precio = request.POST.get("precio")
        proveedor_id = request.POST.get("proveedor_id")
        categoria_id = request.POST.get("categoria_id")

        data = {
            "nombre": nombre,
            "lote": lote,
            "caducidad": caducidad,
            "stock": int(stock),
            "precio": float(precio),
            "proveedor": {"id": int(proveedor_id)},
            "categoria": {"id": int(categoria_id)}
        }

        try:
            response = requests.post("http://localhost:3000/api/medicamentos/create", json=data)
            if response.status_code == 201:
                return redirect("create_medicamento")
            else:
                error = "Error al crear el medicamento."
        except requests.RequestException:
            error = "No se pudo conectar con la API."

    return render(request, "core/inventory.html", {
        "proveedores": proveedores,
        "error": error
    })





def eliminar_medicamento_view(request, medicamento_id):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    if request.method == "POST":
        headers = {
            "Authorization": f"Bearer {token}"
        }

        try:
            response = requests.delete(f"http://localhost:3000/api/medicamentos/delete/{medicamento_id}", headers=headers)
            
            if response.status_code == 204:
                return redirect("inventory")  # Redirige a la vista de inventario
            else:
                # Si falla, renderiza la misma página con error
                return render(request, "core/inventory.html", {"error": "Error al eliminar el medicamento."})
        except requests.RequestException:
            return render(request, "core/inventory.html", {"error": "Error al conectar con la API."})

    # Si no es POST, redirige al inventario
    return redirect("core/inventory")




def detalle_medicamento_view(request, medicamento_id):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}"
    }

    try:
        response = requests.get(f"http://localhost:3000/api/medicamentos/{medicamento_id}", headers=headers)
        if response.status_code == 200:
            medicamento = response.json()
            return render(request, "core/detalle_medicamento.html", {"medicamento": medicamento})
        else:
            return redirect("core/inventory")  # redirección ajustada a tu ruta principal
    except requests.RequestException:
        return redirect("core/inventory")


def inventory_view(request):
    total_medicamentos = None
    try:
        count_response = requests.get("http://localhost:3000/api/medicamentos/count")
        if count_response.status_code == 200:
            data = count_response.json()
            for value in data.values():
                if isinstance(value, int):
                    total_medicamentos = value
                    break
            if total_medicamentos is None:
                total_medicamentos = 0
        else:
            total_medicamentos = 0
    except requests.RequestException as e:
        print("Error al consultar count:", e)
        total_medicamentos = 0

    try:
        response = requests.get("http://localhost:3000/api/medicamentos/all")
        if response.status_code == 200:
            inventory = response.json()
        else:
            inventory = []
    except requests.RequestException:
        inventory = []

    # Paginación usando Paginator de Django
    items_per_page = 6
    paginator = Paginator(inventory, items_per_page)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)  # maneja páginas inválidas automáticamente

    context = {
        'inventory': page_obj.object_list,  # la lista paginada para mostrar
        'page_obj': page_obj,               # el objeto page para la paginación en el template
        'total_medicamentos': total_medicamentos,
    }

    return render(request, 'core/inventory.html', context)

def edit_medicamento_view(request, medicamento_id):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    if request.method == "POST":
        # Recoger datos del formulario
        nombre = request.POST.get("nombre")
        lote = request.POST.get("lote")
        caducidad = request.POST.get("caducidad")
        stock = request.POST.get("stock")
        precio = request.POST.get("precio")
        proveedor_id = request.POST.get("proveedor_id")
        categoria_id = request.POST.get("categoria_id")

        data = {
            "nombre": nombre,
            "lote": lote,
            "caducidad": caducidad,
            "stock": int(stock) if stock else 0,
            "precio": float(precio) if precio else 0,
            "proveedor": {"id": int(proveedor_id) if proveedor_id else None},
            "categoria": {"id": int(categoria_id) if categoria_id else None}
        }

        try:
            url = f"http://localhost:3000/api/medicamentos/update/{medicamento_id}"
            response = requests.put(url, json=data, headers=headers)
            if response.status_code == 200:
                return redirect("inventory")
            else:
                error = f"Error al actualizar medicamento: {response.status_code} - {response.text}"
                # Re-obtenemos datos para mostrar el formulario con error
                medicamento = data  # para rellenar el formulario con lo enviado
                return render(request, "core/edit_medicamento.html", {"medicamento": medicamento, "error": error})
        except requests.RequestException as e:
            error = f"Error de conexión con la API: {e}"
            medicamento = data
            return render(request, "core/edit_medicamento.html", {"medicamento": medicamento, "error": error})

    else:
        # GET: obtener datos para rellenar el formulario
        try:
            url = f"http://localhost:3000/api/medicamentos/{medicamento_id}"
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                medicamento = response.json()
                return render(request, "core/edit_medicamento.html", {"medicamento": medicamento})
            else:
                return redirect("inventory")
        except requests.RequestException:
            return redirect("inventory")

##################################################################################################################################
def get_authenticated_data(request, url):
    token = request.session.get("jwt")
    if not token:
        return redirect("login"), []

    headers = {"Authorization": f"Bearer {token}"}
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return None, response.json()
    except requests.RequestException:
        pass

    return None, []

def supplier_view(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {"Authorization": f"Bearer {token}"}
    try:
        response = requests.get("http://localhost:3000/api/proveedores/all", headers=headers)
        proveedores_list = response.json() if response.status_code == 200 else []
    except requests.RequestException:
        proveedores_list = []

    # Paginación: 10 proveedores por página
    page = request.GET.get('page', 1)
    paginator = Paginator(proveedores_list, 10)

    try:
        proveedores = paginator.page(page)
    except PageNotAnInteger:
        proveedores = paginator.page(1)
    except emptyPage:
        proveedores = paginator.page(paginator.num_pages)

    context = {
        'proveedores': proveedores,
        'page': proveedores.number,
        'total_pages': paginator.num_pages,
    }

    return render(request, 'core/supplier.html', context)

def add_supplier_view(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    error = None

    if request.method == "POST":
        data = {
            "nombre": request.POST.get("nombre"),
            "contacto": request.POST.get("contacto"),
            "direccion": request.POST.get("direccion"),
        }

        try:
            response = requests.post("http://localhost:3000/api/proveedores/create", json=data, headers=headers)
            if response.status_code == 201:
                return redirect("suppliers")
            else:
                error = "No se pudo agregar el proveedor. Verifica los datos."
        except requests.RequestException:
            error = "Error de conexión con la API."

    # Para no perder los proveedores, recuperamos la lista para renderizar
    try:
        response = requests.get("http://localhost:3000/api/proveedores/all", headers=headers)
        proveedores = response.json() if response.status_code == 200 else []
    except requests.RequestException:
        proveedores = []

    context = {
        "proveedores": proveedores,
        "error": error
    }
    return render(request, "core/supplier.html", context)


def edit_supplier_view(request, id):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    if request.method == "POST":
        data = {
            "nombre": request.POST.get("nombre"),
            "contacto": request.POST.get("contacto"),
            "direccion": request.POST.get("direccion")
        }

        try:
            response = requests.put(f"http://localhost:3000/api/proveedores/update/{id}", json=data, headers=headers)
            if response.status_code == 200:
                return redirect("suppliers")
        except requests.RequestException:
            pass

    return redirect("suppliers")


def delete_supplier_view(request, id):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {"Authorization": f"Bearer {token}"}
    try:
        requests.delete(f"http://localhost:3000/api/proveedores/delete/{id}", headers=headers)
    except requests.RequestException:
        pass

    return redirect("suppliers")

################################################################################################

def navbar(request):
    return render(request, 'core/asda.html')
def lista_medicamentos(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {"Authorization": f"Bearer {token}"}

    # Obtener medicamentos
    try:
        response = requests.get("http://localhost:3000/api/medicamentos/all", headers=headers)
        medicamentos = response.json() if response.status_code == 200 else []
    except requests.RequestException:
        medicamentos = []

    # Obtener categorías
    try:
        response_cat = requests.get("http://localhost:3000/api/categorias/all", headers=headers)
        categorias = response_cat.json() if response_cat.status_code == 200 else []
    except requests.RequestException:
        categorias = []

    # Resumen de medicamentos
    total_medicamentos = len(medicamentos)
    stock_critico = sum(1 for m in medicamentos if m.get("stock", 0) < 10)

    caducados = 0
    fecha_hoy = datetime.now().date()
    for med in medicamentos:
        try:
            fecha_caducidad = datetime.strptime(med.get("caducidad", ""), "%Y-%m-%d").date()
            if fecha_caducidad < fecha_hoy:
                caducados += 1
        except (ValueError, TypeError):
            continue

    # Obtener los últimos 10 medicamentos para gráfica
    medicamentos_ordenados = sorted(medicamentos, key=lambda x: x.get('createdAt', ''), reverse=True)
    ultimos_10 = medicamentos_ordenados[:10]
    nombres = [m.get("nombre", "") for m in ultimos_10]
    cantidades = [m.get("stock", 0) for m in ultimos_10]

    # Conteo de medicamentos por categoría
    conteo_por_categoria = {}
    for categoria in categorias:
        categoria_id = categoria.get("id")
        nombre_categoria = categoria.get("nombre", "Sin nombre")
        cantidad = sum(1 for m in medicamentos if m.get("categoria", {}).get("id") == categoria_id)
        conteo_por_categoria[nombre_categoria] = cantidad

    nombres_categorias = list(conteo_por_categoria.keys())
    cantidades_categorias = list(conteo_por_categoria.values())

    # Obtener usuarios y contar por rol
    try:
        response_users = requests.get("http://localhost:3000/api/users/all", headers=headers)
        usuarios = response_users.json() if response_users.status_code == 200 else []
    except requests.RequestException:
        usuarios = []

    conteo_por_rol = {}
    for usuario in usuarios:
        rol = usuario.get("rol", "Sin Rol")
        conteo_por_rol[rol] = conteo_por_rol.get(rol, 0) + 1

    roles_usuarios_django = list(conteo_por_rol.keys())
    cantidades_usuarios_django = list(conteo_por_rol.values())
    stock_critico_nombres = [m.get("nombre") for m in medicamentos if m.get("stock", 0) < 10]

    contexto = {
        "medicamentos": ultimos_10,
        "total_medicamentos": total_medicamentos,
        "stock_critico": stock_critico,
        "caducados": caducados,
        "nombres": nombres,
        "cantidades": cantidades,
        "categorias": categorias,
        "nombres_categorias": nombres_categorias,
        "cantidades_categorias": cantidades_categorias,
        "roles_usuarios_django": roles_usuarios_django,
        "cantidades_usuarios_django": cantidades_usuarios_django,
        "stock_critico_nombres": stock_critico_nombres,
    }
    return render(request, 'core/medicamentos.html', contexto)

###########################################################################################################################


# Vista para agregar un nuevo usuario
def add_user_view(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("user")

    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        apellido = request.POST.get('apellido')
        rol = request.POST.get('rol')
        email = request.POST.get('email')
        contraseña = request.POST.get('contraseña')  # campo correcto

        data = {
            'nombre': nombre,
            'apellido': apellido,
            'rol': rol,
            'email': email,
            'contraseña': contraseña  # <-- aquí debe coincidir con el campo en tu API
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        try:
            response = requests.post("http://localhost:3000/api/users/create", json=data, headers=headers)
            if response.status_code == 201:
                messages.success(request, 'Usuario agregado exitosamente.')
                return redirect('users')  # Redirige a la lista de usuarios
            else:
                error = f"Error al agregar usuario: {response.status_code} - {response.text}"
                return render(request, 'core/add_user.html', {'error': error})
        except requests.RequestException as e:
            return render(request, 'core/add_user.html', {'error': f'Error de conexión: {e}'})

    return render(request, 'core/add_user.html')

# Editar usuario
def edit_user_view(request, user_id):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    if request.method == "POST":
        data = {
            "nombre": request.POST.get("nombre"),
            "apellido": request.POST.get("apellido"),
            "rol": request.POST.get("rol"),
            "email": request.POST.get("email")
        }

        try:
            response = requests.put(f"http://localhost:3000/api/users/update/{user_id}", json=data, headers=headers)
            if response.status_code == 200:
                print("Usuario editado correctamente.")
                return redirect("users")
            else:
                error = f"Error al editar: {response.status_code} - {response.text}"
                return render(request, 'core/edit_user.html', {"user": data, "error": error})
        except requests.RequestException as e:
            error = f"Error de conexión: {e}"
            return render(request, 'core/edit_user.html', {"user": data, "error": error})

    else:
        try:
            response = requests.get(f"http://localhost:3000/api/users/{user_id}", headers=headers)
            if response.status_code == 200:
                user = response.json()
                return render(request, 'core/edit_user.html', {"user": user})
            else:
                return redirect("users")
        except requests.RequestException as e:
            print(f"Error de conexión: {e}")
            return redirect("users")




# Eliminar usuario
def delete_user_view(request, user_id):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = { "Authorization": f"Bearer {token}" }

    try:
        response = requests.delete(f"http://localhost:3000/api/users/delete/{user_id}", headers=headers)
        if response.status_code == 200:
            messages.success(request, 'Usuario eliminado exitosamente.')
        else:
            messages.error(request, f'Error al eliminar usuario: {response.status_code}')
    except requests.RequestException as e:
        messages.error(request, f'Error de conexión: {e}')

    return redirect("users")

# vista de users
def user_view(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    headers = {
        "Authorization": f"Bearer {token}"
    }

    try:
        response = requests.get("http://localhost:3000/api/users/all", headers=headers)
        if response.status_code == 200:
            users = response.json()
        else:
            users = []
    except requests.RequestException:
        users = []

    return render(request, 'core/users.html', {'users': users})







##########################################################################################################################

from django.views.decorators.csrf import csrf_exempt

API_MEDICAMENTOS_URL = "http://localhost:3000/api/medicamentos/all"
API_VENTA_URL = "http://localhost:3000/api/venta"
from django.shortcuts import render, redirect
from django.core.paginator import Paginator
from django.views.decorators.csrf import csrf_exempt
import requests

API_MEDICAMENTOS_URL = "http://localhost:3000/api/medicamentos/all"
API_VENTA_URL = "http://localhost:3000/api/venta"


def obtener_medicamentos_con_token(token):
    headers = {"Authorization": f"Bearer {token}"}
    try:
        response = requests.get(API_MEDICAMENTOS_URL, headers=headers)
        return response.json() if response.status_code == 200 else []
    except requests.RequestException:
        return []


def carrito_view(request):
    token = request.session.get("jwt")
    if not token:
        return redirect("login")

    filtro = request.GET.get("stock")  # con / sin / None
    medicamentos = obtener_medicamentos_con_token(token)

    if filtro == "con":
        medicamentos = [m for m in medicamentos if m.get("stock", 0) > 0]
    elif filtro == "sin":
        medicamentos = [m for m in medicamentos if m.get("stock", 0) <= 0]

    paginator = Paginator(medicamentos, 10)
    page_number = request.GET.get("page", 1)
    page_obj = paginator.get_page(page_number)

    carrito = request.session.get("carrito", [])
    total = sum(item["precio"] * item["cantidad"] for item in carrito)
    compra_exitosa = request.session.pop("compra_exitosa", False)

    return render(request, "core/carrito.html", {
        "medicamentos": page_obj,
        "page_obj": page_obj,
        "carrito": carrito,
        "total_carrito": total,
        "compra_exitosa": compra_exitosa,
        "filtro": filtro,
    })


@csrf_exempt
def agregar_al_carrito(request, medicamento_id):
    if request.method == "POST":
        token = request.session.get("jwt")
        if not token:
            return redirect("login")

        headers = {"Authorization": f"Bearer {token}"}
        cantidad = int(request.POST.get("cantidad", 1))

        try:
            response = requests.get(API_MEDICAMENTOS_URL, headers=headers)
            inventory = response.json() if response.status_code == 200 else []
        except requests.RequestException:
            return redirect("carrito")

        medicamento = next((m for m in inventory if str(m["id"]) == str(medicamento_id)), None)
        if not medicamento:
            return redirect("carrito")

        precio = float(medicamento.get("precio", 0))
        carrito = request.session.get("carrito", [])

        for item in carrito:
            if str(item["id"]) == str(medicamento_id):
                item["cantidad"] += cantidad
                item["total"] = item["cantidad"] * precio
                break
        else:
            carrito.append({
                "id": medicamento["id"],
                "nombre": medicamento["nombre"],
                "precio": precio,
                "cantidad": cantidad,
                "total": precio * cantidad
            })

        request.session["carrito"] = carrito
    return redirect("carrito")

@csrf_exempt
def quitar_del_carrito(request, medicamento_id):
    if request.method == "POST":
        carrito = request.session.get("carrito", [])
        carrito = [item for item in carrito if str(item["id"]) != str(medicamento_id)]
        request.session["carrito"] = carrito
    return redirect("carrito")

@csrf_exempt
def realizar_compra(request):
    if request.method == "POST":
        token = request.session.get("jwt")
        if not token:
            return redirect("login")

        carrito = request.session.get("carrito", [])
        if not carrito:
            return redirect("carrito")

        total = sum(item["precio"] * item["cantidad"] for item in carrito)
        detalles = [
            {
                "medicamentoId": item["id"],
                "cantidad": item["cantidad"],
                "precioUnitario": item["precio"]
            }
            for item in carrito
        ]

        payload = {
            "total": total,
            "detalles": detalles
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        try:
            response = requests.post(API_VENTA_URL, json=payload, headers=headers)
            if response.status_code in [200, 201]:
                request.session["carrito"] = []
                request.session["compra_exitosa"] = True
                return redirect("carrito")
            else:
                error_msg = f"Error al realizar la compra: {response.status_code} - {response.text}"
                return render(request, "core/carrito.html", {
                    "carrito": carrito,
                    "total_carrito": total,
                    "error": error_msg
                })
        except requests.RequestException as e:
            return render(request, "core/carrito.html", {
                "carrito": carrito,
                "total_carrito": total,
                "error": f"Error de conexión con la API: {e}"
            })

    return redirect("carrito")
